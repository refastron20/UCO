#include "Domino.h"
#include <stdio.h>

int main(){
  struct ficha *j1=NULL;
  struct ficha *j2=NULL;
  struct mesa *mesas=NULL;
  struct ficha *monton=NULL;

  mesas=reserva_memoria_mesa();
  monton=crear_monton();
  rellenar_jugadores(&j1,&j2,&monton);
  for (size_t i = 1; i < 8; i++) {
    printf("|%i|%i|\n",j1[i].valores[0],j1[i].valores[1] );
  }
  printf("fichasj1=%s\n", imprimir_vector_fichas(&j1));
  printf("fichasj2=%s\n", imprimir_vector_fichas(&j2));

}
