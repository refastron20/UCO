#ifndef FUNCIONES_MEDIO_NIVEL_HPP
#define FUNCIONES_MEDIO_NIVEL_HPP

int menu();

void nReinasBacktracking();

void nReinasLasVegas();

void ajusteCurva();

#endif
