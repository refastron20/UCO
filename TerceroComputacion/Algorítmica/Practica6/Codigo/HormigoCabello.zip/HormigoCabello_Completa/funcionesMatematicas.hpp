#ifndef FUNCIONESMATEMATICAS_HPP
#define FUNCIONESMATEMATICAS_HPP

#include <vector>

double factorial(const int n);

double media(const std::vector<int> &v);

double varianza(const std::vector<int> &v);

#endif
