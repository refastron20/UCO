#ifndef PLACE_HPP
#define PLACE_HPP

#include <vector>

bool place(const int &k, const std::vector<int> &x);

#endif
