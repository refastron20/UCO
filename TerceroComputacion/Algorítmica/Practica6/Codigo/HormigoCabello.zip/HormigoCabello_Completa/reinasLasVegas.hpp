#ifndef REINASLASVEGAS_HPP
#define REINASLASVEGAS_HPP

#include <vector>


bool LasVegasQueens(const int &n,std::vector<int> &solution);

#endif
