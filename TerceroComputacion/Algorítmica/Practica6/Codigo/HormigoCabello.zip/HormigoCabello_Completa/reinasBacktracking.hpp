#ifndef REINASBACKTRACKING_HPP
#define REINASBACKTRACKING_HPP

#include <vector>


void BacktrackingQueens(const int &n, std::vector<std::vector<int>> &solutions);

#endif
