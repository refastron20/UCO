#!/bin/bash
pruebas=100000;
cd /home/cesi/Escritorio/
for (( pruebas = 100000; pruebas <500000 ; pruebas=pruebas+100000 )); do
  for (( i = 0; i < 20; i++ )); do
    echo "Insertar para $pruebas elementos"
    echo "Insertar para $pruebas elementos" >> insertar.txt
    ./insertar $pruebas &
    pidio=$(pidof mysqld)
    echo $(top -b -n 1 -p $pidio | sed -rn "$ s/.*[SIZR][ ]*([0-9]*\,[0-9]*)[ ]+([0-9]*\,[0-9]*).*$/\1 \2/p" >> insertar.txt)
    echo $(iotop -o -b -n 1 | grep mysqld | sed -rn "1 s/.* ([0-9]*\.[0-9]*\ [BK]\/s)[ ]+([0-9]*\.[0-9]* [BK]\/s).*$/\2/p" >> insertar.txt)
    pid=$(pidof insertar)
    while [[ $(ps | grep -c $pid) -ne 0 ]]; do
      x=0;
    done
    echo "Modificar para $pruebas elementos"
    echo "Modificar para $pruebas elementos" >> modificar.txt
    ./modificar $pruebas &
    pidio=$(pidof mysqld)
    echo $(top -b -n 1 -p $pidio | sed -rn "$ s/.*[SIZR][ ]*([0-9]*\,[0-9]*)[ ]+([0-9]*\,[0-9]*).*$/\1 \2/p" >> modificar.txt)
    echo $(iotop -o -b -n 1 | grep mysqld | sed -rn "1 s/.* ([0-9]*\.[0-9]*\ [BK]\/s)[ ]+([0-9]*\.[0-9]* [BK]\/s).*$/\2/p" >> modificar.txt)
    pid=$(pidof modificar)
    while [[ $(ps | grep -c $pid) -ne 0 ]]; do
      x=0;
    done
    echo "Borrar para $pruebas elementos"
    echo "Borrar para $pruebas elementos" >> borrar.txt
    ./borrar $pruebas &
    pidio=$(pidof mysqld)
    echo $(top -b -n 1 -p $pidio | sed -rn "$ s/.*[SIZR][ ]*([0-9]*\,[0-9]*)[ ]+([0-9]*\,[0-9]*).*$/\1 \2/p" >> borrar.txt)
    echo $(iotop -o -b -n 1 | grep mysqld | sed -rn "1 s/.* ([0-9]*\.[0-9]*\ [BK]\/s)[ ]+([0-9]*\.[0-9]* [BK]\/s).*$/\2/p" >> borrar.txt)
    pid=$(pidof borrar)
    while [[ $(ps | grep -c $pid) -ne 0 ]]; do
      x=0;
    done
  done
done
