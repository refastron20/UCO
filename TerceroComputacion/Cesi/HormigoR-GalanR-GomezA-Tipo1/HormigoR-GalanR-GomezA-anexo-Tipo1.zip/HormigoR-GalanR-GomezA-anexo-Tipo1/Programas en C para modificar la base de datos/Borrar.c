/* librerías que usaremos */
#include <mysql/mysql.h> /* libreria que nos permite hacer el uso de las conexiones y consultas con MySQL */
#include <stdio.h> /* Para poder usar printf, etc. */
#include <time.h>
#include <stdlib.h>


int main(int argc,char *argv[])
{
	MYSQL *conn; /* variable de conexión para MySQL */
	MYSQL_RES *res; /* variable que contendra el resultado de la consuta */
	MYSQL_ROW row; /* variable que contendra los campos por cada registro consultado */
	char *server = "127.0.0.1"; /*direccion del servidor 127.0.0.1, localhost o direccion ip */
	char *user = "root"; /*usuario para consultar la base de datos */
	char *password = ""; /* contraseña para el usuario en cuestion */
	char *database = "CESI"; /*nombre de la base de datos a consultar */
	conn = mysql_init(NULL); /*inicializacion a nula la conexión */

  int COTA=atoi(argv[1]);
	srand(time(NULL));

	/* conectar a la base de datos */
	if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0))
	{ /* definir los parámetros de la conexión antes establecidos */
		fprintf(stderr, "%s\n", mysql_error(conn)); /* si hay un error definir cual fue dicho error */
		exit(1);
	}

	if (mysql_query(conn,"SELECT max(id) FROM basketball_defensive_stats")) {
		fprintf(stderr, "%s\n", mysql_error(conn)); /* si hay un error definir cual fue dicho error*/
		exit(1);
	}

	res = mysql_use_result(conn);
	row=mysql_fetch_row(res);
	int ultimo_id=atoi(row[0])+1;
	mysql_free_result(res);
	char str[100];

	sprintf(str,"DELETE FROM basketball_defensive_stats WHERE id>%d",ultimo_id-1-COTA);
	if (mysql_query(conn,str)) {
		fprintf(stderr, "%s\n", mysql_error(conn));
		exit(1);
	}

	/* se libera la variable res y se cierra la conexión */
	mysql_close(conn);
}
