/*Presupone que la informacion de cada persona esta en una unica linea. 
NO se permiten nombres ni apellidos compuestos
ej.
antonio gomez 1111 1231.3
francisco perez 2222 1345.5
lucia lozano 3333 1111.42
*/

#include "cabecera.h"
#include <stdio.h>
#include <string.h>


/*******************************************************************/
void verFichero(char *fichero)
{ 
 FILE *pFichero;
 struct DatosPersonales persona;
 /* abre fichero para lectura */
 pFichero = fopen(fichero, "r"); 
 /* Comienza a leer datos del fichero hasta que llega al final */
 //Tambien servir�a un while (fscanf(...)!=EOF)
 while (fscanf(pFichero, "%s %s %ld %f", persona.nombre, persona.apellido,
	           &persona.dni, &persona.salario)==NUM_CAMPOS)
 {
    escribirDatosPersonales(persona);
  }
 fclose(pFichero);
}

/*******************************************************************/
long contarRegistros(char *fichero)
{ 
 FILE *pFichero;
 long nRegistros=0;
 struct DatosPersonales persona;
/* abre fichero paa lectura */
 pFichero = fopen(fichero, "r"); 
 /* Comienza a leer datos del fichero hasta que llega al final */
  //Tambien servir�a un while (fscanf(...)!=EOF)
  while (fscanf(pFichero, "%s %s %ld %f", persona.nombre, persona.apellido,
	           &persona.dni, &persona.salario)==NUM_CAMPOS)
 
  {
    nRegistros++;
  }
  
 fclose(pFichero);
 return(nRegistros);
}

/*******************************************************************/
void anadirRegistro(char *fichero, struct DatosPersonales persona)
{
 FILE *pFichero;
 /* abre el fichero para anadir */ 
 pFichero = fopen(fichero, "a"); 
 fprintf(pFichero, "%s %s %ld %.3f\n", persona.nombre, persona.apellido,
	    persona.dni, persona.salario);  /* guarda los datos en el fichero */
 fclose(pFichero);
}

/*******************************************************************/
struct DatosPersonales registro_i(char *fichero, long i)
{
 FILE *pFichero;
 long j;
 struct DatosPersonales persona;
 
 pFichero = fopen(fichero, "r");
 
 for(j=0; j<i; j++)
 {
    fscanf(pFichero, "%s %s %ld %f", persona.nombre, persona.apellido, &persona.dni, &persona.salario);
 }   
 fclose(pFichero);
 
 /* devuelve el registro leido */
 return persona;
}

/********************************************************************/
int buscarporDni(char *fichero, long dni, struct DatosPersonales *persona)
{
 FILE *pFichero;
 int encontrado = 0; /* variables auxiliares para la busqueda */
 int cont;
 struct DatosPersonales auxiliar;
 /* abre fichero para lectura */
 pFichero = fopen(fichero, "r");     
 while (fscanf(pFichero, "%s %s %ld %f", auxiliar.nombre, auxiliar.apellido,
	  &auxiliar.dni, &auxiliar.salario) == NUM_CAMPOS)
  {
    if (auxiliar.dni == dni) /* ha encontrado el registro */
     {
      encontrado = 1;
      *persona = auxiliar; /* almacena en persona el registro encontrado */
     }
   }
 fclose(pFichero); /* se cierra el fichero */
 return encontrado;
}

/********************************************************************/
int mostrarporNombre(char *fichero, char *auxNombre)
{
 FILE *pFichero;
 struct DatosPersonales auxiliar;
 int encontrado = 0;
 /* abre fichero para lectura */ 
 pFichero = fopen(fichero, "r");    
 //Tambien servir�a un while (fscanf(...)!=EOF),
 while (fscanf(pFichero, "%s %s %ld %f", auxiliar.nombre, auxiliar.apellido,  
	  &auxiliar.dni, &auxiliar.salario) == NUM_CAMPOS) 	 	  
  {
   if (strcmp(auxiliar.nombre, auxNombre) == 0)
   /* se ha encontrado un registro con ese nombre */
    {
     escribirDatosPersonales(auxiliar); /* se escriben sus datos */
     encontrado = 1;
    }
  }
 fclose(pFichero); /* se cierra el fichero */
 return encontrado;
} 
/********************************************************************/ 
int actualizarporDni(char* fichero, long dni)
{
  FILE *pFichero1, *pFichero2;
  struct DatosPersonales aux;
  int encontrado = 0;
 
 /* Se abre para lectura el fichero original */
 pFichero1 = fopen(fichero, "r");

 /* Fichero temporal para volcar los registros que no se borran */
 pFichero2 = fopen("temporal", "w");
 
 /* Se recorre el fichero original y los registros que no hay que borrar
    se pasan al fichero temporal */
  //Tambien servir�a un while (fscanf(...)!=EOF)	  
 while(fscanf(pFichero1, "%s %s %ld %f", 
       aux.nombre, aux.apellido, &aux.dni, &aux.salario) == NUM_CAMPOS)
 {
   if (aux.dni == dni)   
   {
   	 aux = introducirDatosPersonales();
   	 encontrado = 1;
   }     
   fprintf(pFichero2, "%s %s %ld %.3f\n", aux.nombre, aux.apellido, aux.dni, aux.salario);
 }
  
  /* Se cierran los ficheros */
  fclose(pFichero1);
  fclose(pFichero2);
  
 /* Se borra el fichero original */
 remove(fichero);
 
 /* Se renombra el temporal con el nombre del original */
 rename("temporal", fichero);   
 
 return(encontrado); 
}  
/********************************************************************/
int borrarporDni(char *fichero, long dni)
{
 FILE *pFichero1, *pFichero2;
 struct DatosPersonales aux;
 int borrado = 0;
 
 /* Se abre para lectura el fichero original */
 pFichero1 = fopen(fichero, "r");

 /* Fichero temporal para volcar los registros que no se borran */
 pFichero2 = fopen("temporal", "w");
 
 /* Se recorre el fichero original y los registros que no hay que borrar
    se pasan al fichero temporal */
 //Tambien servir�a un while (fscanf(...)!=EOF)	
 while(fscanf(pFichero1, "%s %s %ld %f", 
       aux.nombre, aux.apellido, &aux.dni, &aux.salario) == NUM_CAMPOS)
  {
   if (aux.dni != dni)
    fprintf(pFichero2, "%s %s %ld %.3f\n", aux.nombre, aux.apellido, aux.dni, aux.salario);
   else
    borrado = 1; 
  }
  
  /* Se cierran los ficheros */
  fclose(pFichero1);
  fclose(pFichero2);
  
 /* Se borra el fichero original */
 remove(fichero);
 
 /* Se renombra el temporal con el nombre del original */
 rename("temporal", fichero);    
 return(borrado);
}


/********************************************************************/
struct DatosPersonales* ficheroAVector(char* fichero, long* nEle)
{
   FILE *pFichero;
   struct DatosPersonales persona, *V;
   long i=0;
   
   * nEle = contarRegistros(fichero);
   V = reservarVector(*nEle);
   pFichero = fopen(fichero, "r");
   
   /*Leemos todo el fichero*/
   //Tambien servir�a un while (fscanf(...)!=EOF)
   while (fscanf(pFichero, "%s %s %ld %f", persona.nombre, persona.apellido,
	           &persona.dni, &persona.salario)==NUM_CAMPOS)    
   {
      V[i]=persona;
      i++;
   }
      
   fclose(pFichero);
   return(V);
}
/********************************************************************/
void vectorAFichero(char* fichero, struct DatosPersonales* V, long nEle)
{
   FILE* pFichero;
   long i=0;
   
   pFichero = fopen(fichero, "w");
   for (i=0; i<nEle; i++)
   fprintf(pFichero, "%s %s %ld %.3f\n", V[i].nombre, V[i].apellido,
	    V[i].dni, V[i].salario);  
   fclose(pFichero);  
}



	      
	
      


 

 
 
 


 
 
