#include "cabecera.h"
#include <stdio.h>
#include <string.h>

/*******************************************************************/
void verFichero(char *fichero)
{ 
 FILE *pFichero;
 struct DatosPersonales persona;
 
 pFichero = fopen(fichero, "rb"); 
 /* Comienza a leer datos del fichero hasta que llega al final */
 while(fread(&persona,sizeof(struct DatosPersonales),1,pFichero) == 1) 
 /* Comprueba que no ha llegado al final del fichero */
 {
    escribirDatosPersonales(persona); /* Muestra el registro por pantalla */
 }
 fclose(pFichero);
}

/********************************************************************/
long contarRegistros(char *fichero)
{
 FILE *pFichero;
 long numeroRegistros;
 
 /* Se abre para lectura el fichero */
 pFichero = fopen(fichero, "rb");
 
 /* Nos situamos al final del mismo */
 fseek(pFichero, 0, SEEK_END);
 
 /* ftell devuelve el numero de bytes desde el principio del fichero
    hasta la posicion actual que es el final del fichero. */
 numeroRegistros = ftell(pFichero)/sizeof(struct DatosPersonales);
 fclose(pFichero);
 return numeroRegistros;
}

/*******************************************************************/
void anadirRegistro(char *fichero, struct DatosPersonales persona)
{
 FILE *pFichero;
  
 pFichero = fopen(fichero, "ab"); /* abre el fichero para anadir */
 /* guarda los datos en el fichero */
 fwrite(&persona, sizeof(struct DatosPersonales), 1, pFichero); 
 fclose(pFichero);
}

/*******************************************************************/
struct DatosPersonales registro_i(char *fichero, long i)
{
 FILE *pFichero;
 struct DatosPersonales aux;
 
 /* Se abre para lectura el fichero */
 pFichero = fopen(fichero, "rb");
 
 /* Nos desplazamos al final del registro i-1, desde el principio
 del fichero con la funcion fseek*/ 
 fseek(pFichero, (i-1)*sizeof(struct DatosPersonales), SEEK_SET);
 
 /* Se lee el siguiente registro */
 fread(&aux,sizeof(struct DatosPersonales),1,pFichero);

 fclose(pFichero);
 /* devuelve el registro leido */
 return aux;
} 

/*******************************************************************/
int buscarporDni(char *fichero, long dni, struct DatosPersonales *persona)
{
 FILE *pFichero;
 int encontrado = 0; /* variables auxiliares para la busqueda */
 struct DatosPersonales auxiliar;
 /* abre fichero para lectura */    
 pFichero = fopen(fichero, "rb"); 
 while (fread(&auxiliar, sizeof(struct DatosPersonales), 1, pFichero)==1)
  {
    if (auxiliar.dni == dni) 
    /* ha encontrado el registro */
     {
      encontrado = 1;
	  /* almacena en persona el registro encontrado */
      *persona = auxiliar; 
     }
  }
 fclose(pFichero); /* se cierra el fichero */
 return encontrado;
}

/*******************************************************************/
int mostrarporNombre(char *fichero, char *auxNombre)
{
 FILE *pFichero;
 struct DatosPersonales auxiliar;
 int encontrado = 0;
  /* abre fichero para lectura */ 
 pFichero = fopen(fichero, "rb");   
 while(fread(&auxiliar,sizeof(struct DatosPersonales),1,pFichero) == 1) 
  {
   if (strcmp(auxiliar.nombre, auxNombre)==0)
   /* se ha encontrado un registro con ese nombre */
    {
     escribirDatosPersonales(auxiliar); /* se escriben sus datos */
     encontrado = 1;
    }
  }
 fclose(pFichero); /* se cierra el fichero */
 return encontrado;
} 
/********************************************************************/ 
 int actualizarporDni(char* fichero, long dni)
{
 FILE *pFichero;
 struct DatosPersonales aux;
 int encontrado =0;
 
 /* Se abre para lectura y escritura */
 pFichero = fopen(fichero, "r+b");

 /* Se recorre el fichero */ 
 while(fread(&aux, sizeof(struct DatosPersonales),1,pFichero) == 1 )
  {
   /* Se comprueba si el registro tiene ese dni*/
   if (aux.dni == dni)   
   {
   	  aux = introducirDatosPersonales();
   	  encontrado = 1;
             
    /* Nos situamos al principio del registro encontrado */
     fseek(pFichero, -(int)sizeof(struct DatosPersonales), SEEK_CUR);
     /* Se reescribe el registro */
     fwrite(&aux, sizeof(struct DatosPersonales), 1, pFichero); 
     //La siguiente orden es necesario para que en windows  
     //se actualicen los flags de FILE*
     //En Linux, no es necesario, pero se puede dejar
     //El est�ndar requiere fflush para hacer fread despues de fwrite
     fflush(pFichero);
    }  
  }     
  /* Se cierra el fichero*/
  fclose(pFichero);

  return(encontrado);
}

/********************************************************************/
int borrarporDni(char *fichero, long dni_buscar)
{
 FILE *pFichero1, *pFichero2;
 struct DatosPersonales aux;
 int borrado=0;
 
 /* Se abre para lectura el fichero original */
 pFichero1 = fopen(fichero, "rb");

 /* Fichero temporal para volcar los registros que no se borran */
 pFichero2 = fopen("temporal", "wb");
 
 /* Se recorre el fichero original y los registros que no hay que borrar
    se pasan al fichero temporal */
 
 while(fread(&aux, sizeof(struct DatosPersonales),1,pFichero1) == 1 )
  {
   /* Se comprueba si el registro tiene ese dni*/
   if (dni_buscar!=aux.dni)
     fwrite(&aux, sizeof(struct DatosPersonales), 1, pFichero2);
   else
     borrado = 1; 
  }     
  /* Se cierran los ficheros */
  fclose(pFichero1);
  fclose(pFichero2);
  
 /* Se borra el fichero original */
 remove(fichero);
 
 /* Se renombra el temporal con el nombre del original */
 rename("temporal", fichero); 
 return(borrado);   
}

/********************************************************************/ 
struct DatosPersonales* ficheroAVector(char* fichero, long* nEle)
{
   struct DatosPersonales* V;
   FILE* pFichero;
   
   *nEle = contarRegistros(fichero);
   V = reservarVector(*nEle);
   pFichero = fopen(fichero, "rb");
   
   /*Leemos todo el fichero (mas rapido que elemento a elemento)*/
   fread(V, sizeof(struct DatosPersonales),*nEle,pFichero); 
   fclose(pFichero);
   return(V);
}

/********************************************************************/
void vectorAFichero(char* fichero, struct DatosPersonales* V, long nEle)
{
   FILE* pFichero;
   
   pFichero = fopen(fichero, "wb");
   fwrite(V, sizeof(struct DatosPersonales), nEle, pFichero); 
   fclose(pFichero);  
}


