#include "cabecera.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/********************************************************************/
struct DatosPersonales introducirDatosPersonales()
{
 struct DatosPersonales aux;

 /*Introduccion de datos */
 printf("  DNI : ");
 scanf("%ld", &aux.dni); 
 getchar();
 
 printf("Nombre : "); 
 fgets(aux.nombre, MAX_LINEA, stdin);
 aux.nombre[strlen(aux.nombre)-1]='\0';
 
 printf("Apellido :");
 fgets(aux.apellido, MAX_LINEA, stdin);
 aux.apellido[strlen(aux.apellido)-1]='\0';

 printf("Salario:");
 scanf("%f", &aux.salario);
 getchar();
 
 /* devolucion de los datos de la persona */
 return aux;
}

/********************************************************************/
void escribirDatosPersonales(struct DatosPersonales aux)
{
 printf("DNI: %ld\n\tNombre: %s  Apellido: %s  Salario: %.3f\n",
         aux.dni, aux.nombre, aux.apellido, aux.salario);
}

/********************************************************************/
int existeFichero(char *fichero)
{
 FILE *pFichero;
 
 pFichero = fopen(fichero, "r"); /* abre fichero para lectura */
 if (pFichero == NULL) /* el fichero no existe */
  {
   return 0;
  }
 else /* el fichero existe */
  {
   fclose (pFichero);
   return 1;
  }
}

/********************************************************************/
long contarBytes(char *fichero)
{ 
  FILE* f;
  long tam;
  
  if((f=fopen(fichero, "r"))==NULL)
  {
    fprintf(stderr, "\nError: no puedo abrir <%s>", fichero);exit(-1);
  }  
  if(fseek(f, 0L, SEEK_END))
  {
    fprintf(stderr, "\nError: no puedo usar <%s>", fichero); exit(-1);
  }
  tam = ftell(f);
  fclose(f);	
  return(tam);
}

/********************************************************************/
struct DatosPersonales* reservarVector(long nEle)
{
	struct DatosPersonales* V=NULL;
	
	if((V=(struct DatosPersonales*)malloc(nEle*sizeof(struct DatosPersonales)))==NULL)
	{
		printf("\nError: No se ha podido reservar la memoria");
		exit(-1);
	}	
	return(V);
}

/********************************************************************/
void liberarVector(struct DatosPersonales** V)
{
   free(*V);
   *V=NULL;
}

/********************************************************************/
void incrementarSalarios(char* fichero, float incremento)
{
   struct DatosPersonales * V;
   long nEle;
   long i;
   
   /*Para reducir los accesos a disco trabajamos con un vector*/
   V = ficheroAVector(fichero, &nEle);
   
   /*Actualizamos los datos en el vector*/
   for(i=0; i<nEle; i++)
     V[i].salario += incremento;  
   
   /*Escribimos el vector en el fichero*/
   vectorAFichero(fichero, V, nEle);

   /*liberamos el vector*/
   liberarVector(&V);
} 
