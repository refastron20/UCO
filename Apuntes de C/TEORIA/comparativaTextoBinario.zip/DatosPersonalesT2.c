/*Presupone que la informacion de cada persona ocupa tres lineas, una por campo.
SI se permiten nombres y apellidos compuestos
ej.
antonio jose
gomez
1111
1234.22
francisco 
del monte
2222
1345.65
lucia
lozano
3333
956.8
*/


#include "cabecera.h"
#include <stdio.h>
#include <string.h>

/*******************************************************************/
void verFichero(char *fichero)
{ 
 FILE *pFichero;
 struct DatosPersonales persona;
 char linea[MAX_LINEA];
 /* abre fichero para lectura */
 pFichero = fopen(fichero, "r"); 
 /* Comienza a leer datos del fichero hasta que llega al final */
 while (fgets(linea, MAX_LINEA, pFichero)!=NULL)
  {
    //Procesamos nombre   
    if(linea[strlen(linea)-1]=='\n') 
      linea[strlen(linea)-1]='\0';    
    strcpy(persona.nombre, linea);
    
    //Procesamos apellidos - se admiten espacios en blanco
    fgets(linea, MAX_LINEA, pFichero);
     if(linea[strlen(linea)-1]=='\n') 
      linea[strlen(linea)-1]='\0';  
    strcpy(persona.apellido, linea);  
    
    //Procesamos dni
    fgets(linea, MAX_LINEA, pFichero);
    sscanf(linea, "%ld", &persona.dni);
     
	//Procesamos salario
    fgets(linea, MAX_LINEA, pFichero);
    sscanf(linea, "%f", &persona.salario);  
    escribirDatosPersonales(persona);
  }
 fclose(pFichero);
}

/*******************************************************************/
long contarRegistros(char *fichero)
{ 
 FILE *pFichero;
 long nRegistros=0;
 struct DatosPersonales persona;
 char linea[MAX_LINEA];
 /* abre fichero para lectura */
 pFichero = fopen(fichero, "r"); 
 /* Comienza a leer datos del fichero hasta que llega al final */
 while (fgets(linea, MAX_LINEA, pFichero)!=NULL)
  {
    nRegistros++;
  }
 fclose(pFichero);
 return(nRegistros/NUM_CAMPOS);
}

/*******************************************************************/
void anadirRegistro(char *fichero, struct DatosPersonales persona)
{
 FILE *pFichero;
 /* abre el fichero para anadir */ 
 pFichero = fopen(fichero, "a"); 
 fprintf(pFichero, "%s\n%s\n%ld\n%.3f\n", persona.nombre, persona.apellido,
	    persona.dni, persona.salario);  /* guarda los datos en el fichero */
 fclose(pFichero);
}

/*******************************************************************/
struct DatosPersonales registro_i(char *fichero, long i)
{
 FILE *pFichero;
 long j;
 struct DatosPersonales persona;
 char nombre[MAX_LINEA];
 char apellidos[MAX_LINEA];
 char dni[MAX_LINEA]; 
 char salario[MAX_LINEA];
 
 pFichero = fopen(fichero, "r"); 
 
 for(j=0; j<i; j++)
 {
     fgets(nombre, MAX_LINEA, pFichero);
     fgets(apellidos, MAX_LINEA, pFichero);
     fgets(dni, MAX_LINEA, pFichero);
     fgets(salario, MAX_LINEA, pFichero);
 }
 //Procesamos nombre   
 if(nombre[strlen(nombre)-1]=='\n') 
     nombre[strlen(nombre)-1]='\0';    
 strcpy(persona.nombre, nombre);
    
 //Procesamos apellidos - se admiten espacios en blanco
 if(apellidos[strlen(apellidos)-1]=='\n') 
    apellidos[strlen(apellidos)-1]='\0';  
 strcpy(persona.apellido, apellidos);  
    
 //Procesamos dni
 sscanf(dni, "%ld", &persona.dni);     
 sscanf(salario, "%f", &persona.salario);
    
 fclose(pFichero);
 
 /* devuelve el registro leido */
 return persona;
}

/********************************************************************/
int buscarporDni(char *fichero, long dni_buscar, struct DatosPersonales *persona)
{
 FILE *pFichero;
 int encontrado = 0; 
 int cont;
 struct DatosPersonales auxiliar;
 char nombre[MAX_LINEA];
 char apellidos[MAX_LINEA];
 char dni[MAX_LINEA];
 char salario[MAX_LINEA];
 /* abre fichero para lectura */ 
 pFichero = fopen(fichero, "r");    
 
 while ((fgets(nombre, MAX_LINEA, pFichero)!=NULL)&&!encontrado)
  {        
    //Leemos apellidos - se admiten espacios en blanco
    fgets(apellidos, MAX_LINEA, pFichero);    
    //Leemos dni 
    fgets(dni, MAX_LINEA, pFichero);
    sscanf(dni, "%ld", &auxiliar.dni);
    //Leemos salario
    fgets(salario, MAX_LINEA, pFichero);   
	 
    if (auxiliar.dni == dni_buscar) /* ha encontrado el registro */
    {
      encontrado = 1;
      //Procesamos nombre   
      if(nombre[strlen(nombre)-1]=='\n') 
        nombre[strlen(nombre)-1]='\0';    
      strcpy(auxiliar.nombre, nombre);
    
      //Procesamos apellidos - se admiten espacios en blanco
      if(apellidos[strlen(apellidos)-1]=='\n') 
        apellidos[strlen(apellidos)-1]='\0';  
      strcpy(auxiliar.apellido, apellidos);  
     
      //Procesamos el salario
      sscanf(salario, "%f", &auxiliar.salario);
      
	  //almacena en persona el registro encontrado     
      *persona = auxiliar; 
    }   
  }
 
 fclose(pFichero); /* se cierra el fichero */
 return encontrado;
}

/********************************************************************/
int mostrarporNombre(char *fichero, char *auxNombre)
{
 FILE *pFichero;
 struct DatosPersonales auxiliar;
 int encontrado = 0;
 char linea[MAX_LINEA];
 /* abre fichero para lectura */  
 pFichero = fopen(fichero, "r"); 
 
 while (fgets(linea, MAX_LINEA, pFichero)!=NULL)
  {
     //Procesamos nombre   
    if(linea[strlen(linea)-1]=='\n') 
      linea[strlen(linea)-1]='\0';    
    strcpy(auxiliar.nombre, linea);
       
    //Procesamos apellidos - se admiten espacios en blanco
    fgets(linea, MAX_LINEA, pFichero);
     if(linea[strlen(linea)-1]=='\n') 
      linea[strlen(linea)-1]='\0';  
    strcpy(auxiliar.apellido, linea);  
    
    //Procesamos dni 
    fgets(linea, MAX_LINEA, pFichero);
    sscanf(linea, "%ld", &auxiliar.dni);
   
    //Procesamos el salario
    fgets(linea, MAX_LINEA, pFichero);
    sscanf(linea, "%f", &auxiliar.salario);
    
    //se ha encontrado un registro con ese nombre
    if (strcmp(auxiliar.nombre, auxNombre) == 0)
    {
        escribirDatosPersonales(auxiliar); /* se escriben sus datos */
		encontrado = 1;         
    }         
  }

 fclose(pFichero); /* se cierra el fichero */
 return encontrado;
} 
/********************************************************************/ 
int actualizarporDni(char* fichero, long dni_buscar)
{
 FILE *pFichero1, *pFichero2;
 struct DatosPersonales persona;
 char linea[MAX_LINEA];
 int encontrado = 0;
 
 /* Se abre para lectura el fichero original */
 pFichero1 = fopen(fichero, "r");

 /* Fichero temporal para volcar los registros que no se borran */
 pFichero2 = fopen("temporal", "w");
 
 /* Se recorre el fichero original y los registros que no hay que borrar
    se pasan al fichero temporal */
    
 while ((fgets(linea, MAX_LINEA, pFichero1)!=NULL))
  {  
    //Procesamos el nombre   
    if(linea[strlen(linea)-1]=='\n')       
      linea[strlen(linea)-1]='\0';
    strcpy(persona.nombre, linea); 
      
    //Leemos apellidos - se admiten espacios en blanco
    fgets(linea, MAX_LINEA, pFichero1); 
      if(linea[strlen(linea)-1]=='\n')
    linea[strlen(linea)-1]='\0';
    strcpy(persona.apellido, linea);
       
    //Leemos dni 
    fgets(linea, MAX_LINEA, pFichero1);
    sscanf(linea, "%ld", &persona.dni);
    
	//Leemos el salario
    fgets(linea, MAX_LINEA, pFichero1);
    sscanf(linea, "%f", &persona.salario);
	 
    if (persona.dni == dni_buscar)   
    {
   	   persona = introducirDatosPersonales();
   	   encontrado = 1;
    }
    fprintf(pFichero2, "%s\n%s\n%ld\n%.3f\n", persona.nombre, persona.apellido, persona.dni, persona.salario);       
  }     
  /* Se cierran los ficheros */
  fclose(pFichero1);
  fclose(pFichero2);
  
 /* Se borra el fichero original */
 remove(fichero);
 
 /* Se renombra el temporal con el nombre del original */
 rename("temporal", fichero);  
 return(encontrado);  
}       
/********************************************************************/
int borrarporDni(char *fichero, long dni_buscar)
{
 FILE *pFichero1, *pFichero2;
 struct DatosPersonales persona;
 char linea[MAX_LINEA];
 int borrado = 0;
 
 /* Se abre para lectura el fichero original */
 pFichero1 = fopen(fichero, "r");

 /* Fichero temporal para volcar los registros que no se borran */
 pFichero2 = fopen("temporal", "w");
 
 /* Se recorre el fichero original y los registros que no hay que borrar
    se pasan al fichero temporal */
    
  while (fgets(linea, MAX_LINEA, pFichero1)!=NULL)
  {
    //Procesamos nombre   
    if(linea[strlen(linea)-1]=='\n') 
      linea[strlen(linea)-1]='\0';    
    strcpy(persona.nombre, linea);
    
    //Procesamos apellidos - se admiten espacios en blanco
    fgets(linea, MAX_LINEA, pFichero1);
     if(linea[strlen(linea)-1]=='\n') 
      linea[strlen(linea)-1]='\0';  
    strcpy(persona.apellido, linea);  
    
    //Procesamos dni
    fgets(linea, MAX_LINEA, pFichero1);
    sscanf(linea, "%ld", &persona.dni);
    
    //Procesamos salario
    fgets(linea, MAX_LINEA, pFichero1);
    sscanf(linea, "%f", &persona.salario);
    
	//el registro no contiene dni_buscar  
    if (persona.dni != dni_buscar) 
       fprintf(pFichero2, "%s\n%s\n%ld\n%.3f\n", persona.nombre, persona.apellido, persona.dni, persona.salario);         
    else
      borrado = 1;       
  }  
   
  /* Se cierran los ficheros */
  fclose(pFichero1);
  fclose(pFichero2);
  
  /* Se borra el fichero original */
  remove(fichero);
 
  /* Se renombra el temporal con el nombre del original */
  rename("temporal", fichero);  
  return(borrado);  
}

/********************************************************************/
struct DatosPersonales* ficheroAVector(char* fichero, long* nEle)
{
   FILE *pFichero;
   struct DatosPersonales persona, *V;
   long i=0;
   char linea[MAX_LINEA];
   
   *nEle = contarRegistros(fichero);
   V = reservarVector(*nEle);
   pFichero = fopen(fichero, "r");
   
   /*Leemos todo el fichero*/   
   while (fgets(linea, MAX_LINEA, pFichero)!=NULL)
   { 
    //Procesamos nombre   
    if(linea[strlen(linea)-1]=='\n') 
      linea[strlen(linea)-1]='\0';    
    strcpy(persona.nombre, linea);
    
    //Procesamos apellidos - se admiten espacios en blanco
    fgets(linea, MAX_LINEA, pFichero);
     if(linea[strlen(linea)-1]=='\n') 
      linea[strlen(linea)-1]='\0';  
    strcpy(persona.apellido, linea);  
    
    //Procesamos dni
    fgets(linea, MAX_LINEA, pFichero);
    sscanf(linea, "%ld", &persona.dni);
    
    //Procesamos salario
    fgets(linea, MAX_LINEA, pFichero);
    sscanf(linea, "%f", &persona.salario);
	  
    V[i]=persona;
    i++;
   } 
      
   fclose(pFichero);
   return(V);
}	

/********************************************************************/      
void vectorAFichero(char* fichero, struct DatosPersonales* V, long nEle)
{
   FILE* pFichero;
   long i=0;
   
   pFichero = fopen(fichero, "wt");
   for (i=0; i<nEle; i++)
   fprintf(pFichero, "%s\n%s\n%ld\n%.3f\n", V[i].nombre, V[i].apellido,
	    V[i].dni, V[i].salario);  
   fclose(pFichero);  
}



 

 
 
        
	
      


 

 
 
 


 
 
