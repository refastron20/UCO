#include "cabecera.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*******************************************************************/
void verFichero(char *fichero)
{ 
 FILE *pFichero;
 struct DatosPersonales persona;

 pFichero = fopen(fichero, "rb"); /* abre fichero para lectura */
 /* Comienza a leer datos del fichero hasta que llega al final */
 while(fread(&persona,sizeof(struct DatosPersonales),1,pFichero) == 1) 
  {
   /* Hay que comprobar que no est� marcado como borrado */
   if (persona.dni != BORRADO) 
    escribirDatosPersonales(persona); /* Muestra el registro por pantalla */
  }
 fclose(pFichero);
}

/********************************************************************/
long contarRegistros(char *fichero)
{
 FILE *pFichero;
 struct DatosPersonales  persona;
 long numeroRegistros=0;
 
 /* Se abre para lectura el fichero */
 pFichero = fopen(fichero, "rb");
 
 /* Nos situamos al final del mismo */
 while(fread(&persona,sizeof(struct DatosPersonales),1,pFichero) == 1)
 { 
   /*Usar fseek y ftell contaria tambien los marcados para borrar*/                                 
   /*solo contabilizamos si el registro no esta marcado para borrar*/
   if(persona.dni !=BORRADO)
      numeroRegistros++;
 }
 fclose(pFichero);
 return numeroRegistros;
}

/*******************************************************************/
void anadirRegistro(char *fichero, struct DatosPersonales persona)
{
 FILE *pFichero;
 /* abre el fichero para anadir */ 
 pFichero = fopen(fichero, "ab"); 
 /* guarda los datos en el fichero */
 fwrite(&persona, sizeof(struct DatosPersonales), 1, pFichero); 
 fclose(pFichero);
}

/*******************************************************************/
struct DatosPersonales registro_i(char *fichero, long i)
{
 FILE *pFichero;
 long cont=0;
 struct DatosPersonales persona;
 
 /* Se abre para lectura el fichero */
 pFichero = fopen(fichero, "rb");
 
 while(cont<i)
 { 
   /*Usar fseek y ftell contaria tambien los marcados para borrar*/                                 
   fread(&persona,sizeof(struct DatosPersonales),1,pFichero);
   if(persona.dni !=BORRADO)
      cont++;
 }
  
 fclose(pFichero);
 /* devuelve el registro leido */
 return persona;
} 

/*******************************************************************/
int buscarporDni(char *fichero, long dni, struct DatosPersonales *persona)
{
 FILE *pFichero;
 int encontrado = 0;  
 struct DatosPersonales auxiliar;
 /* abre fichero para lectura */
 pFichero = fopen(fichero, "rb");     
 while (fread(&auxiliar, sizeof(struct DatosPersonales), 1, pFichero) == 1)
  {
    if (auxiliar.dni == dni) 
    /* ha encontrado el registro*/
     {
      encontrado = 1;
      *persona = auxiliar; /* almacena en persona el registro encontrado */
     }
   }
 fclose(pFichero); /* se cierra el fichero */
 return encontrado;
}

/*******************************************************************/
int mostrarporNombre(char *fichero, char *auxNombre)
{
 FILE *pFichero;
 struct DatosPersonales auxiliar;
 int encontrado = 0;
 /* abre fichero para lectura */
 pFichero = fopen(fichero, "rb");     
 while(fread(&auxiliar,sizeof(struct DatosPersonales),1,pFichero) == 1) 
 /* se leen todos los registros */
  {
   if (strcmp(auxiliar.nombre, auxNombre) == 0
       && auxiliar.dni!=BORRADO)
   /* se ha encontrado un registro con ese nombre y no est� marcado */
    {
     escribirDatosPersonales(auxiliar); /* se escriben sus datos */
     encontrado = 1;
    }
  }
 fclose(pFichero); /* se cierra el fichero */
 return encontrado;
} 

/*******************************************************************/
int actualizarporDni(char* fichero, long dni)
{
 FILE *pFichero;
 struct DatosPersonales aux;
 int encontrado =0;
 
 /* Se abre para lectura y escritura */
 pFichero = fopen(fichero, "r+b");

 /* Se recorre el fichero */ 
 while(fread(&aux, sizeof(struct DatosPersonales),1,pFichero) == 1 )
  {
   /* Se comprueba si el registro tiene ese dni*/
   if (aux.dni == dni)   
   {
   	  aux = introducirDatosPersonales();
   	  encontrado = 1;
             
    /* Nos situamos al principio del registro encontrado */
     fseek(pFichero, -(int)sizeof(struct DatosPersonales), SEEK_CUR);
     /* Se reescribe el registro */
     fwrite(&aux, sizeof(struct DatosPersonales), 1, pFichero); 
     //La siguiente orden es necesario para que en windows  
     //se actualicen los flags de FILE*
     //En Linux, no es necesario, pero se puede dejar
     //El est�ndar requiere fflush para hacer fread despues de fwrite
     fflush(pFichero);
    }  
  }     
  /* Se cierra el fichero*/
  fclose(pFichero);

  return(encontrado);
} 

/********************************************************************/
int borrarporDni(char *fichero, long dni)
{
 FILE *pFichero;
 struct DatosPersonales aux;
 int encontrado = 0;
 
 /* Se abre para lectura y escritura el fichero */
 pFichero = fopen(fichero, "r+b");
 
 /* Se recorre el fichero original y los registros a borrar se 
    reescriben marcandolos como borrados */
 while((fread(&aux, sizeof(struct DatosPersonales),1,pFichero) == 1 )&&!encontrado)
  {
   /* Se comprueba si el registro tiene ese nombre y no est� marcado */
   if (aux.dni == dni)
    {
     /* Se marca como borrado */
     aux.dni = BORRADO; 
     /* Nos situamos al principio del registro encontrado */
     fseek(pFichero, -(int)sizeof(struct DatosPersonales), SEEK_CUR);
     /* Se reescribe el registro */
     fwrite(&aux, sizeof(struct DatosPersonales), 1, pFichero);
     //La siguiente orden es necesario para que en windows  
     //se actualicen los flags de FILE*
     //En Linux, no es necesario, pero se puede dejar
     //El est�ndar requiere fflush para hacer fread despues de fwrite
     fflush(pFichero);
     /* Se ha borrado al menos un registro */
     encontrado = 1;
    }     
  }
  /* Se cierra el fichero */
  fclose(pFichero);
  return encontrado;
}

/********************************************************************/ 
struct DatosPersonales* ficheroAVector(char* fichero, long* nEle)
{
   struct DatosPersonales* V;
   FILE* pFichero;
   long registros, i;
   
   //Contamos registros, incluidos los borrados
   //contarRegistros solo cuenta los activos, por lo que no es valida
   pFichero = fopen(fichero, "rb"); 
   fseek(pFichero, 0, SEEK_END); 
   registros = ftell(pFichero)/sizeof(struct DatosPersonales);      
  
   V = reservarVector(registros);
   
   /*Leemos todo el fichero (mas rapido que elemento a elemento)*/
   fseek(pFichero, 0, SEEK_SET);  
   fread(V, sizeof(struct DatosPersonales), registros, pFichero); 
   fclose(pFichero);
   
   //Nos quedamos solamente con los registros no borrados
   for(i=0, *nEle=0; i<registros; i++)
   {
      printf("\ncopiando registro: %ld nEle: %ld", i, *nEle);  
   	  if(V[i].dni!=BORRADO)
   	  {
		V[*nEle] = V[i];
   	    (*nEle)++; //Parentesis necesarios
      }
   }
   V= (struct DatosPersonales*) realloc(V, (*nEle)*sizeof(struct DatosPersonales));   
   return(V);
}

/********************************************************************/
void vectorAFichero(char* fichero, struct DatosPersonales* V, long nEle)
{
   FILE* pFichero;
   
   pFichero = fopen(fichero, "wb");
   fwrite(V, sizeof(struct DatosPersonales), nEle, pFichero); 
   fclose(pFichero);  
}

