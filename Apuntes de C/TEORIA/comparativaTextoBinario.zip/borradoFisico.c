#include <stdio.h>
#include "cabecera.h"

/********************************************************************/
/*
   Nombre: borrarMarcados.
   Tipo: void.
   Objetivo: borra los registros marcados para borrar, utilizando un  
             fichero temporal en el que se vuelcan los registros que
	     no se borran, despu�s se borra el fichero original y el
	     temporal se renombra con el nombre del original. Borrado fisico
   Parametros de entrada: 
      - char *fichero: Nombre del fichero.
   Precondiciones: Ha de existir el fichero.
   Valor devuelto: 0 si no borra ninguno y 1 si borra alguno.
*/
/*******************************************************************/
int borrarMarcados(char *fichero);


main()
{
 
  char fichero[15]; /* variable para el nombre del fichero */
  int borrados ;
   /* Introduccion del nombre del fichero para trabajar */
  printf(" Nombre del fichero: ");
  scanf("%s", fichero);
  
  if(existeFichero(fichero))
  {
     borrados = borrarMarcados(fichero); 
     printf("\nBorrado Fisico de <%d> registros", borrados);               
  }
  else
  {
     printf("\nEl archivo no existe");
  }

}

/*******************************************************************/
int borrarMarcados(char *fichero)
{
 FILE *pFichero1, *pFichero2;
 struct DatosPersonales aux;
 int borrados = 0;
 
 /* Se abre para lectura el fichero original */
 pFichero1 = fopen(fichero, "rb");

 /* Se abre para escritura el fichero temporal para volcar los registros
  que no se borran */
 pFichero2 = fopen("temporal", "wb");
 
 /* Se recorre el fichero original y los registros no marcados
    se pasan al fichero temporal */
 while(fread(&aux,sizeof(struct DatosPersonales),1,pFichero1) == 1)
 {
  if(aux.dni != BORRADO)
   /* Si no est� marcado el registro se pasa al temporal */
   fwrite(&aux,sizeof(struct DatosPersonales),1,pFichero2);
  else
   /* al menos hay uno marcado */
   borrados++;
 }
  
 /* Se cierran los ficheros */
 fclose(pFichero1);
 fclose(pFichero2);
  
 /* Se borra el fichero original */
 remove(fichero);
 
 /* Se renombra el temporal con el nombre del original */
 rename("temporal", fichero);
 return borrados;   
}
